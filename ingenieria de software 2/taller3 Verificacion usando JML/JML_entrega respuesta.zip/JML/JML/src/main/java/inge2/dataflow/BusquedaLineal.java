package inge2.dataflow;

public class BusquedaLineal {

    // Busca un elemento en un arreglo de enteros.
    // ESPECIFICAR
    //@ ensures (\exists int i; 0 <= i < arr.length; arr[i] == elem) <==> (\result == true);
    public static boolean busquedaLineal(int elem, int[] arr) {
        boolean result = false;
        //@ loop_invariant (0 <= i) && (i <= arr.length);
        //@ loop_invariant \forall int k; 0 <= k < arr.length; \old(arr[k]) == arr[k];
        //@ loop_invariant (\exists int j; 0 <= j < i; arr[j] == elem) <==> (result == true);
        //@ decreases arr.length -i;
        //@ loop_invariant \old(arr).length == arr.length;
        for (int i = 0; i < arr.length; i++) {
            if (elem == arr[i]) {
                result = true;
            }
        }

        return result;
    }
}