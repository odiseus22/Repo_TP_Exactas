package inge2.dataflow;

public class MapSumaUno {

    // Suma uno a todos los elementos de un array.
    //
    //TODO: ESPECIFICAR
    //@ requires \forall int i; 0 <= i < arr.length; arr[i] < Integer.MAX_VALUE;
    //@ ensures \forall int i; 0 <= i < arr.length; \old(arr[i])+1 == arr[i];
    //@ ensures \old(arr).length == arr.length;
    public static void mapSumaUno(int[] arr) {
        //@ loop_invariant (0 <= i) && (i <= arr.length);
        //@ loop_invariant \forall int k; 0 <= k < i; \old(arr[k])+1 == arr[k];
        //@ loop_invariant \forall int j; i <= j < arr.length; \old(arr[j]) == arr[j];
        //@ loop_writes i, arr[*];
        //@ decreases arr.length -i;
        //@ loop_invariant \old(arr).length == arr.length;
        for (int i = 0; i < arr.length; i++) {
            arr[i] = arr[i] + 1;
        }
        //@ assert \forall int i; 0 <= i < arr.length; \old(arr[i])+1 == arr[i];
    }
}