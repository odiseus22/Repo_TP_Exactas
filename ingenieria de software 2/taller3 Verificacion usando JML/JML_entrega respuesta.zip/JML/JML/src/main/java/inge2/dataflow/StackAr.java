package inge2.dataflow;

public class StackAr {

    /**
     * Capacidad por defecto de la pila.
     */
    //@ spec_public
    private final static int DEFAULT_CAPACITY = 10;

    /**
     * Arreglo que contiene los elementos de la pila.
     */
    //@ public invariant 0 <= elems.length < Integer.MAX_VALUE;
    //@ spec_public
    private final int[] elems;

    /**
     * Indice del tope de la pila.
     */
    //@ public invariant -1 <= top < elems.length;
    //@ spec_public
    private int top = -1;



    // ESPECIFICAR
    //@ ensures (top == -1);
    //@ ensures elems.length == DEFAULT_CAPACITY;
    public StackAr() {
        this(DEFAULT_CAPACITY);
    }

    // ESPECIFICAR
    //@ requires 0<=capacity<Integer.MAX_VALUE;
    //@ ensures -1 == top;
    //@ ensures elems.length == capacity;
    public StackAr(int capacity) {
        elems = new int[capacity];
    }

    // ESPECIFICAR
    //@ ensures (top == -1 <==> \result == true);
    //@ ensures \old(top) == top;
    public boolean isEmpty() {
        return top == -1;
    }

    // ESPECIFICAR
    //@ ensures (top == elems.length-1 <==> \result == true);
    //@ ensures \old(top) == top;
    public boolean isFull() {
        return top == elems.length-1;
    }

    // ESPECIFICAR
    //@ ensures (\result == top+1);
    //@ ensures \old(top) == top;
    public int size() {
        return top+1;
    }

    // ESPECIFICAR
    //@ requires top < elems.length-1;
    //@ ensures \forall int i; 0 <= i < \old(top); \old(elems[i]) == elems[i];
    //@ ensures \old(top) + 1 == top;
    //@ ensures elems[top] == o;
    //@ ensures elems.length == \old(elems.length);
    public void push(int o) {
        elems[top+1] = o;
        top++;
    }

    // ESPECIFICAR
    //@ requires top >= 0;
    //@ requires top <= Integer.MAX_VALUE;
    //@ ensures \forall int i; 0 <= i < \old(top) - 1; \old(elems[i]) == elems[i];
    //@ ensures \old(top) == top + 1;
    //@ ensures \result == \old(elems[\old(top)]);
    public int pop() {
        top--;
        return elems[top+1];
    }

    // ESPECIFICAR
    //@ requires top >= 0;
    //@ ensures \forall int i; 0 <= i < top; \old(elems[i]) == elems[i];
    //@ ensures \old(top) == top;
    //@ ensures \result == \old(elems[top]);
    public int peek() {
        return elems[top];
    }
}

