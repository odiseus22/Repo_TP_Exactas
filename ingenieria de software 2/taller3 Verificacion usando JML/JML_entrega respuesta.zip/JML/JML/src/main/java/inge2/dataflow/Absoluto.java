package inge2.dataflow;

public class Absoluto {

    // Calcula el valor absoluto de un número entero.
    // Si el número es negativo, devuelve el opuesto.
    //
    // ESPECIFICAR:
    //@ requires (n > Integer.MIN_VALUE);
    //@ ensures (\result >= 0);
    //@ ensures (\old(n) >= 0 ==> \result == \old(n));
    //@ ensures (\old(n) < 0 ==> \result == -1 * \old(n));

    public static int valorAbsoluto(int n) {
        if (n < 0) {
            return -n;
        } else {
            return n;
        }
    }
}