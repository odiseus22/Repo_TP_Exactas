package inge2.dataflow;

public class StackAr {

    /**
     * Capacidad por defecto de la pila.
     */
    private final static int DEFAULT_CAPACITY = 10;

    /**
     * Arreglo que contiene los elementos de la pila.
     */
    private final int[] elems;

    /**
     * Indice del tope de la pila.
     */
    private int top = -1;

    //@ TODO: ESPECIFICAR
    public StackAr() {
        this(DEFAULT_CAPACITY);
    }

    //@ TODO: ESPECIFICAR
    public StackAr(int capacity) {
        // TODO: IMPLEMENTAR
        throw new UnsupportedOperationException("Not implemented yet");
    }

    //@ TODO: ESPECIFICAR
    public boolean isEmpty() {
        // TODO: IMPLEMENTAR
        throw new UnsupportedOperationException("Not implemented yet");
    }

    //@ TODO: ESPECIFICAR
    public boolean isFull() {
        // TODO: IMPLEMENTAR
        throw new UnsupportedOperationException("Not implemented yet");
    }

    //@ TODO: ESPECIFICAR
    public int size() {
        // TODO: IMPLEMENTAR
        throw new UnsupportedOperationException("Not implemented yet");
    }

    //@ TODO: ESPECIFICAR
    public void push(int o) {
        // TODO: IMPLEMENTAR
        throw new UnsupportedOperationException("Not implemented yet");
    }

    //@ TODO: ESPECIFICAR
    public int pop() {
        // TODO: IMPLEMENTAR
        throw new UnsupportedOperationException("Not implemented yet");
    }

    //@ TODO: ESPECIFICAR
    public int peek() {
        // TODO: IMPLEMENTAR
        throw new UnsupportedOperationException("Not implemented yet");
    }
}

