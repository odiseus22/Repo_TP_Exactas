package inge2.dataflow.pointstoanalysis;

import jdk.nashorn.internal.objects.annotations.Setter;
import soot.jimple.*;
import soot.jimple.internal.JInstanceFieldRef;
import soot.jimple.internal.JimpleLocal;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class PointsToVisitor extends AbstractStmtSwitch<Void> {

    private final PointsToGraph pointsToGraph;

    public PointsToVisitor(PointsToGraph pointsToGraph) {
        this.pointsToGraph = pointsToGraph;
    }

    @Override
    public void caseAssignStmt(AssignStmt stmt) {
        boolean isLeftLocal = stmt.getLeftOp() instanceof JimpleLocal;
        boolean isRightLocal = stmt.getRightOp() instanceof JimpleLocal;

        boolean isLeftField = stmt.getLeftOp() instanceof JInstanceFieldRef;
        boolean isRightField = stmt.getRightOp() instanceof JInstanceFieldRef;

        boolean isRightNew = stmt.getRightOp() instanceof AnyNewExpr;

        if (isRightNew) { // x = new A()
            processNewObject(stmt);
        } else if (isLeftLocal && isRightLocal) { // x = y
            processCopy(stmt);
        } else if (isLeftField && isRightLocal) { // x.f = y
            processStore(stmt);
        } else if (isLeftLocal && isRightField) { // x = y.f
            processLoad(stmt);
        }
    }

    private void processNewObject(AssignStmt stmt) {
        String leftVariableName = stmt.getLeftOp().toString();
        Node nodeName = pointsToGraph.getNodeName(stmt);

        // TODO: Set<Node> nodosAlcanzables = new HashSet<Node>();
        Set<Node> nuevo = new HashSet<Node>();
        nuevo.add(nodeName);
        pointsToGraph.mapping.put(leftVariableName, nuevo);

    }

    private void processCopy(AssignStmt stmt) {
        String leftVariableName = stmt.getLeftOp().toString();
        String rightVariableName = stmt.getRightOp().toString();

        // TODO:
        Set<Node> alcanzablesRight = pointsToGraph.mapping.get(rightVariableName);

        pointsToGraph.mapping.put(leftVariableName, alcanzablesRight);
    }

    private void processStore(AssignStmt stmt) { // x.f = y
        JInstanceFieldRef leftFieldRef = (JInstanceFieldRef) stmt.getLeftOp();
        String leftVariableName = leftFieldRef.getBase().toString();
        String fieldName = leftFieldRef.getField().getName();
        String rightVariableName = stmt.getRightOp().toString();

        // TODO:
        // Un eje (n1, f, n2) indica que el los objetos representados por el nodo n1 tienen un campo f que apunta al/los
        // objetos representados por n2.

        //(Nodos(X), f , NODOS(Y))
        Set<Node> x = pointsToGraph.getNodesForVariable(leftVariableName);
        Set<Node> y = pointsToGraph.getNodesForVariable(rightVariableName);

        Set<Axis> ejesNuevos = new HashSet<Axis>();

        for(Node node_x : x) {
            for(Node node_y : y) {
                Axis nuevoEje = new Axis(node_x, fieldName, node_y);
                ejesNuevos.add(nuevoEje);
            }
        }

        pointsToGraph.axis.addAll(ejesNuevos);
                
    }

    private void processLoad(AssignStmt stmt) { // x = y.f
        String leftVariableName = stmt.getLeftOp().toString();
        JInstanceFieldRef rightFieldRef = (JInstanceFieldRef) stmt.getRightOp();
        String rightVariableName = rightFieldRef.getBase().toString();
        String fieldName = rightFieldRef.getField().getName();

        // TODO: Set<Node> getReachableNodesByField(Node node, String fieldName)
        // Set<Node> getNodesForVariable(String variableName)
        
        Set<Node> y = pointsToGraph.getNodesForVariable(rightVariableName);

        Set<Node> alcanzadosPorCampo = new HashSet<Node>();
        
        for (Node node : y) {
            Set<Node> nodos = pointsToGraph.getReachableNodesByField(node, fieldName);
            alcanzadosPorCampo.addAll(nodos);
        }

        pointsToGraph.mapping.put(leftVariableName, alcanzadosPorCampo);
    }
}
