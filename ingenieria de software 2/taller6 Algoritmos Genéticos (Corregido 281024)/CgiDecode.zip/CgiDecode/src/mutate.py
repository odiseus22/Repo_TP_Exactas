from random import choice
from typing import List

from src.create_population import create_test_case, get_random_character


def add_character(test_case: str) -> str:
    # TODO: COMPLETAR
    return test_case


def remove_character(test_case: str) -> str:
    # TODO: COMPLETAR
    return test_case


def modify_character(test_case: str) -> str:
    # TODO: COMPLETAR
    return test_case


def add_test_case(individual: List[str]) -> List[str]:
    # TODO: COMPLETAR
    return individual


def remove_test_case(individual: List[str]) -> List[str]:
    # TODO: COMPLETAR
    return individual


def modify_test_case(individual: List[str]) -> List[str]:
    # TODO: COMPLETAR
    return individual


def mutate(individual: List[str]) -> List[str]:
    # TODO: COMPLETAR
    return individual

