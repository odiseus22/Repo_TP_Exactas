#!./venv/bin/python
import unittest

from random import seed
from src.genetic_algorithm import GeneticAlgorithm


class TestGeneticAlgorithm(unittest.TestCase):
    def test1(self):
        # TODO COMPLETADO
        seed(1)
        ga = GeneticAlgorithm()
        best_individual = ga.run()

        self.assertEqual(2, ga.get_generation()) # generaciones totales que realizo
        self.assertEqual(0.0, ga.get_fitness_best_individual()) # branch coverage del mejor

    def test2(self):
        # TODO COMPLETADO
        seed(360)
        ga = GeneticAlgorithm()
        best_individual = ga.run()

        self.assertEqual(3, ga.get_generation())  # generaciones totales que realizo
        self.assertEqual(0.0, ga.get_fitness_best_individual())  # branch coverage del mejor

    def test3(self):
        # TODO COMPLETADO
        seed(420)
        ga = GeneticAlgorithm()
        best_individual = ga.run()

        self.assertEqual(5, ga.get_generation())  # generaciones totales que realizo
        self.assertEqual(0.0, ga.get_fitness_best_individual())  # branch coverage del mejor
