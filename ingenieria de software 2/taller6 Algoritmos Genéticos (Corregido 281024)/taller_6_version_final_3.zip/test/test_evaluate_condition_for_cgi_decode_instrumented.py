#!./venv/bin/python
import unittest
from src.cgi_decode import cgi_decode
from src.cgi_decode_instrumented import cgi_decode_instrumented
from src.evaluate_condition import clear_maps, get_true_distance, get_false_distance


class TestEvaluateConditionForCgiDecodeInstrumented(unittest.TestCase):
    def testExample(self):
        # TODO listo

        #caso1
        clear_maps()
        self.assertEqual("e ", cgi_decode_instrumented("e+"))
        self.assertEqual(0, get_true_distance(1))   # entra en el while con i=0 < 2
        self.assertEqual(0, get_true_distance(2))   # entra con c='+'
        self.assertEqual(64, get_true_distance(3))  # abs(ord('e')-ord('%'))=abs(101-37)=64
        self.assertEqual(None, get_true_distance(4)) # no se llega a esta condición
        self.assertEqual(None, get_true_distance(5)) # no se llega a esta condición
        
        self.assertEqual(0, get_false_distance(1))  # sale del while después de recorrer el string
        self.assertEqual(0, get_false_distance(2))  # no entra con c='e'
        self.assertEqual(0, get_false_distance(3))  # no entra con c='e'
        self.assertEqual(None, get_false_distance(4)) # no se llega a esta condición
        self.assertEqual(None, get_false_distance(5)) # no se llega a esta condición
        
        #caso2
        clear_maps() 
        self.assertEqual("A", cgi_decode_instrumented("%41"))
        self.assertEqual(0, get_true_distance(1)) # entra con i=0 < 3
        self.assertEqual(6, get_true_distance(2)) # abs(ord('+')-ord('%'))=abs(43-37)=6
        self.assertEqual(0, get_true_distance(3)) # entra con c=%
        self.assertEqual(0, get_true_distance(4)) # 4 pertenece a hex_values
        self.assertEqual(0, get_true_distance(5)) # 1 pertenece a hex_values
        
        self.assertEqual(0, get_false_distance(1)) # sale del while despues de recorrer el string
        self.assertEqual(0, get_false_distance(2)) # con c=+ no entra
        self.assertEqual(1, get_false_distance(3)) # entra con c=%, con k=1 queda 1 dist false
        self.assertEqual(1, get_false_distance(4)) # 4 pertenece, con k=1 queda 1 dist false
        self.assertEqual(1, get_false_distance(5)) # 1 pertenece, con k=1 queda 1 dist false

        #caso3
        clear_maps()
        with self.assertRaises(ValueError) as error1:
            cgi_decode_instrumented("%1z")
        self.assertEqual(str(error1.exception), "Invalid encoding: digit low is not a hex digit")
        self.assertEqual(0, get_true_distance(1))  # entra con i=0 < 3
        self.assertEqual(6, get_true_distance(2))  # abs(ord('+')-ord('%'))=abs(43-37)=6
        self.assertEqual(0, get_true_distance(3))  # entra con c=%
        self.assertEqual(0, get_true_distance(4))  # 1 pertenece a hex_values
        self.assertEqual(20, get_true_distance(5))  # abs(ord('z')-ord('f'))=20

        self.assertEqual(3, get_false_distance(1)) # queda 3-0=3 porque termina con el raise ValueError
        self.assertEqual(0, get_false_distance(2))  # con c=+ no entra
        self.assertEqual(1, get_false_distance(3)) # entra con c=%, con k=1 queda 1 dist false
        self.assertEqual(1, get_false_distance(4)) # 1 pertenece, con k=1 queda 1 dist false
        self.assertEqual(0, get_false_distance(5)) # z no pertenece a hex_values


        #caso4
        clear_maps()
        with self.assertRaises(ValueError) as error2:
            cgi_decode_instrumented("%z1")
        self.assertEqual(str(error2.exception), "Invalid encoding: digit high is not a hex digit")
        self.assertEqual(0, get_true_distance(1))  # entra con i=0 < 3
        self.assertEqual(6, get_true_distance(2))  # abs(ord('+')-ord('%'))=abs(43-37)=6
        self.assertEqual(0, get_true_distance(3))  # entra con c=%
        self.assertEqual(20, get_true_distance(4))   # abs(ord('z')-ord('f'))=20
        self.assertEqual(None, get_true_distance(5))  # no llega a esta condición

        self.assertEqual(3, get_false_distance(1))  # queda 3-0=3 porque termina con el raise ValueError
        self.assertEqual(0, get_false_distance(2))  # con c=+ no entra
        self.assertEqual(1, get_false_distance(3))  # entra con c=%, con k=1 queda 1 dist false
        self.assertEqual(0, get_false_distance(4))  # z no pertenece a hex_values
        self.assertEqual(None, get_false_distance(5))  # no llega a esta condición