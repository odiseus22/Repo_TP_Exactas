#!./venv/bin/python
import unittest
from src.get_fitness_cgi_decode import get_fitness_cgi_decode


class TestGetFitnessCgiDecode(unittest.TestCase):
    def testExample(self):
        # tests usando como base los tests de evaluate_condition_for_cgi_decode_instrumented
        self.assertAlmostEqual(4.984615384615385, get_fitness_cgi_decode(["e+"])) # (64/65)+4*1 = 4.984615384615385
        self.assertAlmostEqual(2.357142857142857, get_fitness_cgi_decode(["%41"])) # (6/7)+3*(1/2) = 2.357142857142857
        self.assertAlmostEqual(3.5595238095238093, get_fitness_cgi_decode(["%1z"])) # (6/7)+(20/21)+(3/4)+2*(1/2) = 3.5595238095238093
        self.assertAlmostEqual(5.059523809523809, get_fitness_cgi_decode(["%z1"])) # (6/7)+(20/21)+2*1+(3/4)+(1/2) = 5.059523809523809

        self.assertAlmostEqual(1.0, get_fitness_cgi_decode(["%41", "e+"]))  # 2*(1/2) = 1
        self.assertAlmostEqual(1.8571428571428572, get_fitness_cgi_decode(["%41", "%1z"]))  #(6/7)+2*(1/2) = 1.8571428571428572

        self.assertAlmostEqual(0.0, get_fitness_cgi_decode(["e+", "%41", "%1z", "%z1"]))

        # ejemplos del enunciado:
        self.assertAlmostEqual(2.357142857142857, get_fitness_cgi_decode(["%AA"]))
        self.assertAlmostEqual(1.8571428571428572, get_fitness_cgi_decode(["\%AA"]))
        self.assertAlmostEqual(3.03021978021978, get_fitness_cgi_decode(["\%AU"]))
        self.assertAlmostEqual(4.53021978021978, get_fitness_cgi_decode(["\%UU"]))
        self.assertAlmostEqual(4.972222222222222, get_fitness_cgi_decode(["Hello+Reader"]))
        self.assertAlmostEqual(8.5, get_fitness_cgi_decode([""]))
        self.assertAlmostEqual(5.357142857142858, get_fitness_cgi_decode(["\%"]))
        self.assertAlmostEqual(5.523809523809524, get_fitness_cgi_decode(["\%1"]))
        self.assertAlmostEqual(6.5, get_fitness_cgi_decode(["+"]))
        self.assertAlmostEqual(4.666666666666666, get_fitness_cgi_decode(["+\%1"]))
        self.assertAlmostEqual(2.9404761904761907, get_fitness_cgi_decode(["\%1+"]))
        self.assertAlmostEqual(0.0, get_fitness_cgi_decode(["\%1+", "%+1", "a+%AA"]))
