#!./venv/bin/python
import unittest
from src.cgi_decode import cgi_decode


class TestCgiDecode(unittest.TestCase):
    def testExample(self):
        #COMPLETADO

        self.assertEqual("e ", cgi_decode("e+"))
        self.assertEqual("A", cgi_decode("%41"))
        

        with self.assertRaises(ValueError) as error1:
            cgi_decode("%1z")
        self.assertEqual(str(error1.exception), "Invalid encoding: digit low is not a hex digit")

        with self.assertRaises(ValueError) as error2:
            cgi_decode("%z1")
        self.assertEqual(str(error2.exception), "Invalid encoding: digit high is not a hex digit")
