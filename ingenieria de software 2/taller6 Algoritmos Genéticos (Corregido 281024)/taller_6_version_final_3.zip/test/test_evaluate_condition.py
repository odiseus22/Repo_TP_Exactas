#!./venv/bin/python
import unittest
from src.evaluate_condition import evaluate_condition


class TestEvaluateCondition(unittest.TestCase):
    def testExample(self):
        # TODO COMPLETADO EJ2


        self.assertTrue(evaluate_condition(1, "Eq", "10", "10"))
        self.assertFalse(evaluate_condition(1, "Eq", "20", "10"))
        
        self.assertTrue(evaluate_condition(1, "Ne", "10", "20"))
        self.assertFalse(evaluate_condition(1, "Ne", "10", "10"))
    
        self.assertTrue(evaluate_condition(1, "Lt", "10", "20"))
        self.assertFalse(evaluate_condition(1, "Lt", "10", "10"))
        
        self.assertTrue(evaluate_condition(1, "Gt", "20", "10"))
        self.assertFalse(evaluate_condition(1, "Gt", "10", "10"))
                
        self.assertTrue(evaluate_condition(1, "Le", "10", "20"))
        self.assertTrue(evaluate_condition(1, "Le", "10", "10"))
        self.assertFalse(evaluate_condition(1, "Le", "15", "10"))

        self.assertTrue(evaluate_condition(1, "Ge", "20", "10"))
        self.assertTrue(evaluate_condition(1, "Ge", "10", "10"))
        self.assertFalse(evaluate_condition(1, "Ge", "10", "15"))
        
        # chars
        self.assertTrue(evaluate_condition(1, "Eq", "a", "a"))
        self.assertFalse(evaluate_condition(1, "Eq", "a", "b"))

        self.assertTrue(evaluate_condition(1, "Ne", "a", "b"))
        self.assertFalse(evaluate_condition(1, "Ne", "a", "a"))

        self.assertTrue(evaluate_condition(1, "Lt", "a", "b"))
        self.assertFalse(evaluate_condition(1, "Lt", "b", "a"))

        self.assertTrue(evaluate_condition(1, "Gt", "b", "a"))
        self.assertFalse(evaluate_condition(1, "Gt", "a", "b"))

        self.assertTrue(evaluate_condition(1, "Le", "a", "b"))
        self.assertTrue(evaluate_condition(1, "Le", "a", "a"))
        self.assertFalse(evaluate_condition(1, "Le", "b", "a"))

        self.assertTrue(evaluate_condition(1, "Ge", "b", "a"))
        self.assertTrue(evaluate_condition(1, "Ge", "b", "b"))
        self.assertFalse(evaluate_condition(1, "Ge", "a", "b"))

        #diccionarios
        dic1 = { "10": "valor1", "20": "valor2", "30": "valor3"}
        self.assertTrue(evaluate_condition(1, "In", "20", dic1))
        self.assertFalse(evaluate_condition(1, "In", "40", dic1))

        dic2 = {"a": "valor1", "b": "valor2", "c": "valor3"}
        self.assertTrue(evaluate_condition(1, "In", "b", dic2))
        self.assertFalse(evaluate_condition(1, "In", "d", dic2))



