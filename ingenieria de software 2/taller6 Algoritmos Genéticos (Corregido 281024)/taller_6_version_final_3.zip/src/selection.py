import random
from random import sample
from typing import Tuple


def selection(fitness_by_individual: dict, tournament_size: int) -> Tuple[str, float]:
    """
    fitness_by_individual: Diccionario que contiene a los individuos de la población como keys y su fitness como valores.
    tournament_size: Tamaño del torneo (entero positivo).
    """
    winner = None
    # TODO: COMPLETANDO
    #  (Tournament selection)

    # elegimos tournament_size individuos (claves del diccionario)
    # puede haber claves repetidas según aclaró JPG.
    claves_dict = list(fitness_by_individual.keys())
    claves_elegidos = random.choices(claves_dict, k=tournament_size)

    # ahora de los elegidos, tenemos que elegir el ganador (menor fitness en este taller)
    winner = claves_elegidos[0]
    for clave in claves_elegidos:
        if fitness_by_individual[clave] < fitness_by_individual[winner]:
            winner = clave

    return winner, fitness_by_individual[winner]
