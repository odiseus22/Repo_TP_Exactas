from sys import maxsize
from random import random
from typing import List

from src.create_population import create_population
from src.crossover import crossover
from src.evaluate_population import evaluate_population
from src.mutate import mutate
from src.selection import selection

class GeneticAlgorithm():
    def __init__(self):
        self.population_size = 100
        self.tournament_size = 5
        self.p_crossover = 0.70
        self.p_mutation = 0.20

        self.generation = 0
        self.best_individual = None
        self.fitness_best_individual = None

    def get_best_individual(self):
        return self.best_individual
    
    def get_fitness_best_individual(self):
        return self.fitness_best_individual
    
    def get_generation(self):
        return self.generation

    def generate_crossovers(self, population: List[List[str]], fitness_by_individual: dict) -> List[List[str]]:
        # TODO COMPLETANDO
        # Pista: no olvidarse de usar selection, deben crear una nueva poblacion
        winner_indice1, fitness_de_winner1 = selection(fitness_by_individual, self.tournament_size)
        winner_indice2, fitness_de_winner2 = selection(fitness_by_individual, self.tournament_size)

        offspring1, offspring2 = crossover(population[int(winner_indice1)], population[int(winner_indice2)])

        return [offspring1, offspring2]

    def generate_mutations(self, population: List[List[str]]) -> List[List[str]]:
        # TODO (usamos mutate para mutar todos)
        mutaciones = []

        for individual in population:
            mutaciones.append(mutate(individual))

        return mutaciones

    def covered_all_branches(self, fitness_individual: float) -> bool:
        # TODO (si el fitness es 0 cubrió todo)

        return fitness_individual == 0

    def run(self):
        # Generar y evaluar la poblacion inicial
        poblacion_anterior = create_population(self.population_size)                                # TODO COMPLETANDO

        fitness_by_individual_anterior = evaluate_population(poblacion_anterior)                             # TODO COMPLETANDO

        # Continuar mientras la cantidad de generaciones es menor que 1000
        # y no haya ningun individuo que cubra todos los objetivos
        while self.generation < 1000 and (self.fitness_best_individual is None or not self.covered_all_branches(self.fitness_best_individual)):   # TODO COMPLETANDO

            # Producir una nueva poblacion en base a la anterior.
            # Usar selection, crossover y mutation.
            self.generation += 1
            poblacion_actual = []

            while len(poblacion_actual) < self.population_size:
                selection_y_crossover = self.generate_crossovers(poblacion_anterior, fitness_by_individual_anterior) # TODO COMPLETANDO
                selecction_crossover_y_mutados = self.generate_mutations(selection_y_crossover) #aca hay 2 individuos

                # Una vez creada, reemplazar la poblacion anterior con la nueva
                poblacion_actual = selecction_crossover_y_mutados + poblacion_actual

            # Evaluar la nueva poblacion e imprimir el mejor valor de fitness
            fitness_by_individual_actual = evaluate_population(poblacion_actual)                             # TODO COMPLETANDO

            #calculo al mejor individuo de mi generacion
            best_individual_indice_parcial = 0
            fitness_best_individual_parcial = fitness_by_individual_actual[0]
            for individual, puntaje in fitness_by_individual_actual.items():
                if puntaje < fitness_best_individual_parcial:
                    fitness_best_individual_parcial = puntaje
                    best_individual_indice_parcial = individual

            self.best_individual = poblacion_actual[best_individual_indice_parcial]                           # TODO COMPLETADO
            self.fitness_best_individual = fitness_best_individual_parcial                      # TODO COMPLETADO

            #paso la informacion para la siguiente iteracion
            poblacion_anterior = poblacion_actual
            fitness_by_individual_anterior = fitness_by_individual_actual

        # retornar el mejor individuo de la ultima generacion
        return self.best_individual