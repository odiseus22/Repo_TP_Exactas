from typing import List

from src.cgi_decode_instrumented import cgi_decode_instrumented
from src.evaluate_condition import clear_maps, get_false_distance, get_true_distance


def get_fitness_cgi_decode(test_suite: List[str]) -> float:
    # Borro la información de branch coverage de ejecuciones anteriores
    # Recuerden que los diccionarios true_distances y false_distances son globales
    clear_maps()

    fitness = 0
    # TODO: COMPLETADO
    for caso in test_suite:
        try:
            cgi_decode_instrumented(caso)   # actualiza valores de ambos diccionarios teniendo en cuenta este caso
        except:
            continue
    
    for i in range(1, 6):
        dist_true = get_true_distance(i)
        if dist_true == None:
            fitness += 1
        else:
            fitness += (dist_true / (dist_true + 1))

    for i in range(1,6):
        dist_false = get_false_distance(i)
        if dist_false == None:
            fitness += 1
        else:
            fitness += (dist_false/(dist_false+1))

    return fitness
