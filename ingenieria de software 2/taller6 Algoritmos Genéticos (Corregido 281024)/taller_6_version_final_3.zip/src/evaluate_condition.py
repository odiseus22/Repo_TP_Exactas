import sys
from sys import maxsize
from typing import Dict, Union

# Inicializar mappings globales
distances_true: Dict[int, int] = {}
distances_false: Dict[int, int] = {}


def update_maps(condition_num: int, d_true: int, d_false: int):
    global distances_true, distances_false

    if condition_num in distances_true.keys():
        distances_true[condition_num] = min(
            distances_true[condition_num], d_true)
    else:
        distances_true[condition_num] = d_true

    if condition_num in distances_false.keys():
        distances_false[condition_num] = min(
            distances_false[condition_num], d_false)
    else:
        distances_false[condition_num] = d_false


def clear_maps():
    global distances_true, distances_false
    distances_true.clear()
    distances_false.clear()


def get_true_distance(condition_num: int) -> Union[int, None]:
    global distances_true
    if condition_num in distances_true.keys():
        return distances_true[condition_num]
    else:
        return None


def get_false_distance(condition_num: int) -> Union[int, None]:
    global distances_false
    if condition_num in distances_false.keys():
        return distances_false[condition_num]
    else:
        return None


def has_reached_condition(condition_num: int) -> bool:
    global distances_true, distances_false
    return condition_num in distances_true.keys() or condition_num in distances_false.keys()


def evaluate_condition(condition_num: int, op: str, lhs: Union[str, Dict], rhs: Union[str, Dict]) -> bool:
    # TODO: COMPLETADO EJ2
    # decidimos que k=1 como en los ejemplos del enunciado, pero se puede cambiar
    k = 1

    #chequeamos tipos

    if isinstance(lhs, str) and isinstance(rhs, str):
        # ambos son char o ambos son int
        if len(lhs) == 1 and len(rhs) == 1:
            lhs = ord(lhs)
            rhs = ord(rhs)
        else:
            lhs = int(lhs)
            rhs = int(rhs)

    if isinstance(rhs, Dict):
        existe_clave_en_dic = False
        lhsEsChar = len(lhs) == 1
        if lhsEsChar:
            min_dist=maxsize
            for clave in rhs.keys():
                existe_clave_en_dic = ord(clave) == ord(lhs)
                if existe_clave_en_dic:
                    break
                min_dist = min(min_dist, abs(ord(clave)-ord(lhs)))

            if existe_clave_en_dic:
                update_maps(condition_num, 0, 1)
            else:
                update_maps(condition_num, min_dist, 0)
            return  existe_clave_en_dic
        else:
            min_dist = maxsize
            for clave in rhs.keys():
                existe_clave_en_dic = int(clave) == int(lhs)

                if existe_clave_en_dic:
                    break
                min_dist = min(min_dist, abs(int(clave) - int(lhs)))

            if existe_clave_en_dic:
                update_maps(condition_num, 0, 1)
            else:
                update_maps(condition_num, min_dist, 0)
            return  existe_clave_en_dic

    if op == "Eq":
        if lhs == rhs:
            update_maps(condition_num, 0, k)
            return True
        else:
            update_maps(condition_num, abs(lhs-rhs), 0)
            return False

    elif op == "Ne":
        if lhs != rhs:
            update_maps(condition_num, 0, abs(lhs-rhs))
            return True
        else:
            update_maps(condition_num, k, 0)
            return False

    elif op == "Lt":
        if lhs < rhs:
            update_maps(condition_num, 0, rhs-lhs)
            return True
        else:
            update_maps(condition_num, lhs-rhs+k, 0)
            return False

    elif op == "Gt":
        if lhs > rhs:
            update_maps(condition_num, 0, lhs-rhs)
            return True
        else:
            update_maps(condition_num, rhs-lhs+k, 0)
            return False

    elif op == "Le":
        if lhs <= rhs:
            update_maps(condition_num, 0, rhs-lhs+k)
            return True
        else:
            update_maps(condition_num, lhs-rhs, 0)
            return False

    else:   # op == "Ge":
        if lhs >= rhs:
            update_maps(condition_num, 0, lhs-rhs+k)
            return True
        else:
            update_maps(condition_num, rhs-lhs, 0)
            return False

