from random import choice, randint
from string import printable
from typing import List


def get_random_character():
    # TODO: COMPLETADO
    caracteres = printable
    random_character = choice(caracteres)
    return random_character


def create_test_case() -> str:
    # TODO: COMPLETADO
    largo_random_string = randint(0,10)
    string_random = ""
    for _ in range(largo_random_string):
        string_random += get_random_character()
    return string_random


def create_individual() -> List[str]:
    # TODO: COMPLETADO
    largo_random_lista = randint(1, 15)
    lista_de_individuos = []
    for _ in range(largo_random_lista):
        lista_de_individuos.append(create_test_case())
    return lista_de_individuos

def create_population(population_size) -> List[List[str]]:
    population = []

    # TODO: COMPLETAR
    for i in range(population_size):
        population.append(create_individual())

    return population
