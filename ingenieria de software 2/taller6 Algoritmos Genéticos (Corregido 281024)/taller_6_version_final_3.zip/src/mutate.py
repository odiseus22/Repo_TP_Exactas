from random import choice, randint
from typing import List
from src.create_population import create_test_case, get_random_character

def add_character(test_case: str) -> str:
    # TODO: COMPLETADO
    # decidimos agregar caracter en posición random,
    # otra opción que consideramos era agregarlo al final
    random_character = get_random_character()
    if len(test_case) > 0:
        posicion = randint(0, len(test_case) - 1)
        test_case = test_case[:posicion] + random_character + test_case[posicion:]
    else:
        test_case = test_case + random_character
    return test_case

def remove_character(test_case: str) -> str:
    # TODO: COMPLETADO
    posicion = randint(0, len(test_case) - 1)
    test_case = test_case[:posicion] + test_case[posicion+1:]
    return test_case

def modify_character(test_case: str) -> str:
    # TODO: COMPLETADO
    random_character = get_random_character()
    posicion = randint(0, len(test_case) - 1)
    test_case = test_case[:posicion] + random_character + test_case[posicion+1:]
    return test_case

def add_test_case(individual: List[str]) -> List[str]:
    # TODO: COMPLETADO
    posicion = randint(0, len(individual) - 1)
    case_test_nuevo = create_test_case()
    individual.insert(posicion, case_test_nuevo)
    return individual

def remove_test_case(individual: List[str]) -> List[str]:
    # TODO: COMPLETADO
    indice = randint(0, len(individual) - 1)
    individual.pop(indice)
    return individual

def modify_test_case(individual: List[str]) -> List[str]:
    # TODO: COMPLETADO
    indice = randint(0, len(individual) - 1)
    test_case_elegido = individual[indice]
    funciones = []
    if len(test_case_elegido) > 1:
        funciones.append(remove_character)
    if len(test_case_elegido) >= 1:
        funciones.append(modify_character)
    if len(test_case_elegido) < 10:
        funciones.append(add_character)
    funcion_elegida = choice(funciones)
    test_case_mutado = funcion_elegida(test_case_elegido)
    individual[indice] = test_case_mutado
    return individual

def mutate(individual: List[str]) -> List[str]:
    # TODO: COMPLETADO
    funciones = []
    if len(individual) > 1:
        funciones.append(remove_test_case)
    if len(individual) >= 1:
        funciones.append(modify_test_case)
    if len(individual) < 15:
        funciones.append(add_test_case)
    funcion_elegida = choice(funciones)
    individual_mutado = funcion_elegida(individual)
    return individual_mutado