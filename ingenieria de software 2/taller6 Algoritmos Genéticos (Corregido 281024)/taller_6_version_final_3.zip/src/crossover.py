from random import randint
from typing import List, Tuple


    # elegimos un punto random para hacer crossover
def crossover(parent1: List[str], parent2: List[str]) -> Tuple[List[str], List[str]]:
    corte = randint(0, min(len(parent1) - 1, len(parent2) - 1))
    offspring1 = parent1[:corte] + parent2[corte:]
    offspring2 = parent2[:corte] + parent1[corte:]

    return offspring1, offspring2
